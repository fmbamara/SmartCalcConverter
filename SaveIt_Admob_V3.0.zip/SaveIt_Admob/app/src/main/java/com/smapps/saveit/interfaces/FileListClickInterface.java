package com.smapps.saveit.interfaces;

import java.io.File;

public interface FileListClickInterface {
    void getPosition(int position, File file);
}
