package com.smapps.saveit.util;

import android.content.ClipboardManager;

public abstract class ClipboardListener implements ClipboardManager.OnPrimaryClipChangedListener {

}
